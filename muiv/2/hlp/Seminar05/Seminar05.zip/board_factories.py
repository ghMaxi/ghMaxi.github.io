from board import Board
from side import Side


def standard_chess_board():
    board_size = 8
    black = Side('b')
    white = Side('w')
    result = Board(board_size, board_size)
    return result
