from typing import List, Optional
from pieces.piece import Piece


class Board:
    def __init__(self, width: int, height: int):
        self.cells: List[List[Optional[Piece]]] = list()
        for row in range(width):
            self.cells.append(list())
            for col in range(height):
                self.cells[row].append(None)

    def place(self, piece: Piece, x: int, y: int):
        self.cells[x][y] = piece
