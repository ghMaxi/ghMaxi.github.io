from side import Side
from abc import ABC, abstractmethod


class Piece(ABC):
    def __init__(self, side: Side):
        self.side = side

    def is_enemy(self, other):
        return self.side != other.side

    @abstractmethod
    def symbol(self):
        return 'F'

    def __repr__(self):
        return f'{self.side.symbol}{self.symbol()}'

    def __str__(self):
        return f'{self.side.symbol}{self.symbol()}'

